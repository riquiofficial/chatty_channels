from django.apps import AppConfig


class ChattyChannelsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatty_channels_app'
