# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['chatty_channels',
 'chatty_channels.chatty_channels',
 'chatty_channels.chatty_channels_app',
 'chatty_channels.chatty_channels_app.migrations']

package_data = \
{'': ['*'],
 'chatty_channels.chatty_channels_app': ['templates/chatty_channels_app/*']}

install_requires = \
['Django>=3.2.8,<4.0.0',
 'channels>=3.0.4,<4.0.0',
 'django-channels>=0.7.0,<0.8.0',
 'django-environ>=0.8.1,<0.9.0',
 'django-rest-framework>=0.1.0,<0.2.0',
 'requests>=2.26.0,<3.0.0']

setup_kwargs = {
    'name': 'chatty-channels',
    'version': '0.1.0',
    'description': 'Testing a chat app with Django Channels',
    'long_description': None,
    'author': 'Richard Quigley',
    'author_email': 'rquigley@taylorhopkinson.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
